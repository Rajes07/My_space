package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployController {
	
	@Autowired
	private EmployService serv;
	
	
	@RequestMapping(value="/search/{empId}")
	public Employee Searchid(@PathVariable int empId) {
		return serv.search(empId);
	}
	
	
	
	@RequestMapping(value="/show")
	public List<Employee> ShowEmployyee(){
		return serv.findall();
	}
	

}
