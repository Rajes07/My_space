package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Transactional
@Service
public class EmployService {
	
	@Autowired
	private EmployRepo repo;
	
	
	
	public List<Employee> findall(){
		return repo.findAll();
	
	}
	
	public Employee search(int empId) {
		return repo.findById(empId).get();
	}

}
