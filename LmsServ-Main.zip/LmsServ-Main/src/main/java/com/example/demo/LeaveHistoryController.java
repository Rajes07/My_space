package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveHistoryController {

	@Autowired
	public LeaveHistoryService serv;
	
	@Autowired
	public LeaveHistoryDao dao;
	
	
	@PostMapping("/approveordeny/{levid}/{mgrid}/{mgrcomments}/{status}")
    public String approveordeny(@PathVariable int levid,@PathVariable int mgrid,@PathVariable String mgrcomments,@PathVariable String status) {
		System.out.println(levid);
		System.out.println(mgrid);
		System.out.println(mgrcomments);
		System.out.println(status);
		return serv.approveordeny(levid, mgrid, mgrcomments, status);
	}
	@PostMapping("/applyLeave")
	public String add(@RequestBody LeaveHistory ls) {
		return serv.applyLeave(ls);
	}
	
	@GetMapping("/getleave/{id}")
	public List<LeaveHistory> getleaveinfobyempid(@PathVariable int id){
		return serv.byid(id);
	}
	
	
	@RequestMapping(value="/pending")
	public LeaveHistory[] pendog() {
		return serv.pending();
	}
	
	@RequestMapping(value="/searchleave/{leaveId}")
	public LeaveHistory search(@PathVariable int leaveId){
		return serv.search(leaveId);
	}
	@RequestMapping(value="/showLeave")
	public List<LeaveHistory> showAll(){
		return serv.findall();
	}
}
