package com.example.demo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.stereotype.Repository;

@Repository
public class LeaveHistoryDao {
	
	@Autowired
	private JdbcTemplate jdbc;
	
	public LeaveHistory[] pendingLeaves(){
		
		String cmd="Select * from leave_history where LEAVE_STATUS='PENDING'";
	
	    List <LeaveHistory> Str=jdbc.query(cmd,new Object[] {},new RowMapper<LeaveHistory>() {

			@Override
			public LeaveHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				LeaveHistory l= new LeaveHistory();
				l.setLeaveId(rs.getInt("LEAVE_ID"));
				l.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				l.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
				l.setEmpId(rs.getInt("EMP_ID"));
				l.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				l.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				l.setLeaveType(rs.getString("LEAVE_TYPE"));
				l.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				l.setLeaveReason(rs.getString("LEAVE_REASON"));
				return l;
			}
			});
		
				
				return Str.toArray(new LeaveHistory[Str.size()]);
		
	}
	
	

	public List<LeaveHistory> serachbyempid(int id){
		String cmd = "select * from leave_history where EMP_ID=?";
		List<LeaveHistory> LeaveList=jdbc.query(cmd,new Object[] {id}, new RowMapper<LeaveHistory>() {

			public LeaveHistory mapRow(ResultSet rs, int arg1) throws SQLException {
			    LeaveHistory lh=new LeaveHistory();
			    lh.setLeaveId(rs.getInt("LEAVE_ID"));
			    lh.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
			    lh.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
			    lh.setEmpId(rs.getInt("EMP_ID"));
			    lh.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
			    lh.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
			    lh.setLeaveType(rs.getString("LEAVE_TYPE"));
			    lh.setLeaveStatus(rs.getString("LEAVE_STATUS"));
			    lh.setLeaveReason(rs.getString("LEAVE_REASON"));
			    
			    return lh;
				
			}


			
		});
		return LeaveList;
	}
	public void updateLeaveStatus(int levid, String  mgr_comments,String status) {
		String cmd = "Update leave_history set LEAVE_MNGR_COMMENTS=?,LEAVE_STATUS=?  WHERE LEAVE_ID=?";
		jdbc.update(cmd, new Object[] {mgr_comments,status,levid});
	}

}
