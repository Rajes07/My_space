package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveHistoryService {

	
	@Autowired
	private LeavehistoryRepo repo;
	
	@Autowired
	private LeaveHistoryDao dao;
	
	@Autowired
	private EmployDao empdao;
	
	@Autowired
	private EmployService serv;
	
	public List<LeaveHistory> byid(int id){
		return dao.serachbyempid(id);
	}
	
	public LeaveHistory[] pending() {
		return dao.pendingLeaves();
	}
	
	public LeaveHistory search(int leaveId) {
		return repo.findById(leaveId).get();
	}
	
	public List<LeaveHistory> findall(){
		return repo.findAll();
	}
	
	
	
	public String applyLeave(LeaveHistory ls) {
		long ms=ls.getLeaveEndDate().getTime()-ls.getLeaveStartDate().getTime();
		long m = ms / (1000 * 24 * 60 * 60);
	    int days = (int) m;
	    days = days + 1;
	    if(days <= 0) {
	    	return "Leave end date cannot be less than Leave start date"; 
	    }
	    
	    ls.setLeaveNoOfDays(days);
	    int noOfDays=empdao.getleavebalnce(ls.getEmpId());
	    
	    if(ls.getLeaveNoOfDays()>noOfDays) {
	    	return "Insuffient lve balance";
	    	
	    }
	    ls.setLeaveStatus("PENDING");
	    repo.save(ls);
	    empdao.updateLeaveBal(noOfDays, days);
	    return"leave applied";
	    
		
	}
	
	public String approveordeny(int leaveId,int mgrid,String status,String mgrcomments) {
		LeaveHistory ls=repo.findById(leaveId).get();
		Employee emp=serv.search(ls.getEmpId());
		if(emp.getEmpId()!=mgrid){
			return "UnAuthourized Manager";
		}
		if(status.toLowerCase().equals("yes")) {
		dao.updateLeaveStatus(ls.getLeaveId(), mgrcomments, "APPROVED");
			return "Leave Approved by Managar";
		}
		else {
			dao.updateLeaveStatus(ls.getLeaveId(), mgrcomments, "DENIED");
			
		}
		return "Leave denied";
	}
	


}
